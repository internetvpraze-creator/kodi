# -*- coding: utf-8 -*-
"""
Automaticke prehravani filmu ze slozky (Startup) - Kodi service add-on
---------------------------------------------------------------------
Folder:
  /storage/emulated/0/Movies/

Behavior:
- Builds a playlist from ALL video files in the folder (sorted by filename).
- Starts playback on Kodi startup.
- Sets repeat = ALL (so a single video loops forever).
- Shows a 2-second on-screen "SpořilovNet" text at the very start of playback
  (bottom-right) via a tiny temporary ASS subtitle file.
"""

import os
import xbmc
import xbmcvfs
import xbmcgui

VIDEO_DIR = "/storage/emulated/0/Movies/"

EXTS = (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".ts", ".webm")
STARTUP_DELAY_MS = 12000
RECURSIVE = False

# Overlay text on startup (ASS subtitle for 2 seconds)
SHOW_STARTUP_TEXT = True
STARTUP_TEXT = "SpořilovNet"
STARTUP_TEXT_SECONDS = 2.0

def log(msg):
    xbmc.log(f"[AutoplayMovies] {msg}", xbmc.LOGINFO)

def list_media_files(dir_path, recursive=False):
    out = []
    if not dir_path.endswith("/"):
        dir_path += "/"
    if not xbmcvfs.exists(dir_path):
        return out

    dirs, files = xbmcvfs.listdir(dir_path)

    for f in files:
        if f.lower().endswith(EXTS):
            out.append(os.path.join(dir_path, f))

    if recursive:
        for d in dirs:
            sub = os.path.join(dir_path, d)
            if not sub.endswith("/"):
                sub += "/"
            out.extend(list_media_files(sub, recursive=True))

    return out

def set_repeat_all():
    try:
        active = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Player.GetActivePlayers"}')
        if '"playerid"' not in active:
            return
        m = active.split('"playerid":', 1)[1]
        digits = ''.join(ch for ch in m if ch.isdigit())
        pid = int(digits[:2] or "1")
        xbmc.executeJSONRPC(
            f'{{"jsonrpc":"2.0","id":2,"method":"Player.SetRepeat","params":{{"playerid":{pid},"repeat":"all"}}}}'
        )
    except Exception as e:
        log(f"RepeatAll failed: {e}")

def fullscreen_on():
    try:
        xbmc.executebuiltin("Action(Fullscreen)")
    except Exception:
        pass

def write_startup_ass(text, seconds):
    """
    Create a tiny ASS subtitle file in Kodi temp folder.
    Alignment=9 -> bottom-right.
    """
    ass_path = "special://temp/sporilovnet_startup.ass"
    # Kodi's ASS parser expects standard sections
    # Use a readable size and a thin outline for visibility.
    ass = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,44,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,2,0,9,30,30,30,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.00,0:00:{seconds:05.2f},Default,,0,0,0,,{text}
"""
    try:
        f = xbmcvfs.File(ass_path, "w")
        f.write(ass)
        f.close()
        return ass_path
    except Exception as e:
        log(f"ASS write failed: {e}")
        return None

def show_startup_text_once(player):
    if not SHOW_STARTUP_TEXT:
        return
    ass_path = write_startup_ass(STARTUP_TEXT, STARTUP_TEXT_SECONDS)
    if not ass_path:
        return
    try:
        # Wait until video playback actually starts
        for _ in range(40):
            if player.isPlayingVideo():
                break
            xbmc.sleep(100)
        if player.isPlayingVideo():
            # Load and enable subtitles (ASS will show only for 0-2s)
            player.setSubtitles(ass_path)
            try:
                player.showSubtitles(True)
            except Exception:
                pass
    except Exception as e:
        log(f"Startup text failed: {e}")

def main():
    xbmc.sleep(STARTUP_DELAY_MS)

    media = list_media_files(VIDEO_DIR, recursive=RECURSIVE)
    if not media:
        log(f"No media found or folder not accessible: {VIDEO_DIR}")
        return

    media.sort()

    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    for p in media:
        # Create ListItem so Kodi has a proper item; leave subtitles handling to runtime
        li = xbmcgui.ListItem(path=p)
        pl.add(p, li)

    log(f"Starting playlist with {len(media)} items from {VIDEO_DIR}")
    player = xbmc.Player()
    player.play(pl)

    xbmc.sleep(800)
    set_repeat_all()
    fullscreen_on()

    # Overlay text only at start of playback (overall startup)
    show_startup_text_once(player)

if __name__ == "__main__":
    main()
