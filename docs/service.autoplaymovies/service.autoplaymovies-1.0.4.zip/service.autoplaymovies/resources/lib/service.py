# -*- coding: utf-8 -*-
"""
Automaticke prehravani filmu ze slozky (Startup) - Kodi service add-on
---------------------------------------------------------------------
- Loads video files from a configurable folder (default: /storage/emulated/0/Movies/)
- Builds a playlist (sorted by filename) and starts playback on Kodi startup
- Sets repeat = ALL (single file loops forever)
- Optional 2-second bottom-right "SpořilovNet" startup text (can be disabled in settings)
"""

import os
import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon

EXTS = (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".ts", ".webm")
STARTUP_DELAY_MS = 12000
RECURSIVE = False

DEFAULT_VIDEO_DIR = "/storage/emulated/0/Movies/"
DEFAULT_SHOW_TEXT = True
STARTUP_TEXT = "SpořilovNet"
STARTUP_TEXT_SECONDS = 2.0

def log(msg):
    xbmc.log(f"[AutoplayMovies] {msg}", xbmc.LOGINFO)

def get_settings():
    addon = xbmcaddon.Addon()
    video_dir = addon.getSettingString("video_dir") or DEFAULT_VIDEO_DIR
    show_text = addon.getSettingBool("show_startup_text") if hasattr(addon, "getSettingBool") else (addon.getSetting("show_startup_text") == "true")
    if not video_dir:
        video_dir = DEFAULT_VIDEO_DIR
    # Normalize
    if not video_dir.endswith("/"):
        video_dir += "/"
    return video_dir, bool(show_text)

def list_media_files(dir_path, recursive=False):
    out = []
    if not dir_path.endswith("/"):
        dir_path += "/"
    if not xbmcvfs.exists(dir_path):
        return out

    dirs, files = xbmcvfs.listdir(dir_path)

    for f in files:
        if f.lower().endswith(EXTS):
            out.append(os.path.join(dir_path, f))

    if recursive:
        for d in dirs:
            sub = os.path.join(dir_path, d)
            if not sub.endswith("/"):
                sub += "/"
            out.extend(list_media_files(sub, recursive=True))

    return out

def set_repeat_all():
    try:
        active = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Player.GetActivePlayers"}')
        if '"playerid"' not in active:
            return
        m = active.split('"playerid":', 1)[1]
        digits = ''.join(ch for ch in m if ch.isdigit())
        pid = int(digits[:2] or "1")
        xbmc.executeJSONRPC(
            f'{{"jsonrpc":"2.0","id":2,"method":"Player.SetRepeat","params":{{"playerid":{pid},"repeat":"all"}}}}'
        )
    except Exception as e:
        log(f"RepeatAll failed: {e}")

def fullscreen_on():
    try:
        xbmc.executebuiltin("Action(Fullscreen)")
    except Exception:
        pass

def write_startup_ass(text, seconds):
    """
    Create a tiny ASS subtitle file in Kodi temp folder.
    Alignment=9 -> bottom-right.
    """
    ass_path = "special://temp/sporilovnet_startup.ass"
    ass = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,44,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,2,0,9,30,30,30,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.00,0:00:{seconds:05.2f},Default,,0,0,0,,{text}
"""
    try:
        f = xbmcvfs.File(ass_path, "w")
        f.write(ass)
        f.close()
        return ass_path
    except Exception as e:
        log(f"ASS write failed: {e}")
        return None

def show_startup_text_once(player):
    ass_path = write_startup_ass(STARTUP_TEXT, STARTUP_TEXT_SECONDS)
    if not ass_path:
        return
    try:
        for _ in range(40):
            if player.isPlayingVideo():
                break
            xbmc.sleep(100)
        if not player.isPlayingVideo():
            return

        # Prefer translated real path if available
        try:
            real_path = xbmcvfs.translatePath(ass_path)
        except Exception:
            real_path = ass_path

        player.setSubtitles(real_path)
        try:
            player.showSubtitles(True)
        except Exception:
            pass
    except Exception as e:
        log(f"Startup text failed: {e}")

def main():
    xbmc.sleep(STARTUP_DELAY_MS)

    video_dir, show_text = get_settings()

    media = list_media_files(video_dir, recursive=RECURSIVE)
    if not media:
        log(f"No media found or folder not accessible: {video_dir}")
        return

    media.sort()

    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    for p in media:
        li = xbmcgui.ListItem(path=p)
        pl.add(p, li)

    log(f"Starting playlist with {len(media)} items from {video_dir}")
    player = xbmc.Player()
    player.play(pl)

    xbmc.sleep(800)
    set_repeat_all()
    fullscreen_on()

    if show_text:
        show_startup_text_once(player)

if __name__ == "__main__":
    main()
